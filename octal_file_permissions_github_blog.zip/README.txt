GitHub Pages blog files

1. Upload index.html and the images folder to the root of your GitHub repository.
2. Commit the files to the main branch.
3. Open Settings > Pages.
4. Choose Deploy from a branch, branch main, folder /(root), then Save.
5. Your blog will be published at https://YOUR-USERNAME.github.io/REPOSITORY-NAME/
